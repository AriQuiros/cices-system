package com.example.dataclassactivitiesapp

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class Persona(
    val nombre: String,
    val edad: Int,
    val correo: String,
    val telefono: String,
    val direccion: String
) : Parcelable
