@echo off
cls
REM Ejecutar inicialización de BD forzando UTF-8
call "%~dp0ejecutar_sql_utf8.bat" "%~dp0CICESBD.sql" "system/root"