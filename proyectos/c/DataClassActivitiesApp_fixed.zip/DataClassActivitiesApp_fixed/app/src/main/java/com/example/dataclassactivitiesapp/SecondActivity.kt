package com.example.dataclassactivitiesapp

import android.os.Build
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.dataclassactivitiesapp.databinding.ActivitySecondBinding

class SecondActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySecondBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySecondBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val persona = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            intent.getParcelableExtra(EXTRA_PERSONA, Persona::class.java)
        } else {
            @Suppress("DEPRECATION")
            intent.getParcelableExtra(EXTRA_PERSONA)
        }

        if (persona != null) {
            binding.tvNombre.text = persona.nombre
            binding.tvEdad.text = persona.edad.toString()
            binding.tvCorreo.text = persona.correo
            binding.tvTelefono.text = persona.telefono
            binding.tvDireccion.text = persona.direccion
        } else {
            binding.tvNombre.text = getString(R.string.no_data)
            binding.tvEdad.text = getString(R.string.no_data)
            binding.tvCorreo.text = getString(R.string.no_data)
            binding.tvTelefono.text = getString(R.string.no_data)
            binding.tvDireccion.text = getString(R.string.no_data)
        }

        binding.btnVolver.setOnClickListener {
            finish()
        }
    }

    companion object {
        const val EXTRA_PERSONA = "extra_persona"
    }
}
