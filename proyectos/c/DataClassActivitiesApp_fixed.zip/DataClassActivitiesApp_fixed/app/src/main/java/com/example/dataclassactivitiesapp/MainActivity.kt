package com.example.dataclassactivitiesapp

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.dataclassactivitiesapp.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnEnviar.setOnClickListener {
            enviarDatos()
        }

        binding.btnLimpiar.setOnClickListener {
            limpiarCampos()
        }
    }

    private fun enviarDatos() {
        val nombre = binding.etNombre.text.toString().trim()
        val edadTexto = binding.etEdad.text.toString().trim()
        val correo = binding.etCorreo.text.toString().trim()
        val telefono = binding.etTelefono.text.toString().trim()
        val direccion = binding.etDireccion.text.toString().trim()

        when {
            nombre.isEmpty() || edadTexto.isEmpty() || correo.isEmpty() || telefono.isEmpty() || direccion.isEmpty() -> {
                Toast.makeText(this, "Complete todos los campos", Toast.LENGTH_SHORT).show()
            }
            edadTexto.toIntOrNull() == null -> {
                Toast.makeText(this, "La edad debe ser numérica", Toast.LENGTH_SHORT).show()
            }
            !android.util.Patterns.EMAIL_ADDRESS.matcher(correo).matches() -> {
                Toast.makeText(this, "Ingrese un correo válido", Toast.LENGTH_SHORT).show()
            }
            else -> {
                val persona = Persona(
                    nombre = nombre,
                    edad = edadTexto.toInt(),
                    correo = correo,
                    telefono = telefono,
                    direccion = direccion
                )

                val intent = Intent(this, SecondActivity::class.java).apply {
                    putExtra(SecondActivity.EXTRA_PERSONA, persona)
                }
                startActivity(intent)
            }
        }
    }

    private fun limpiarCampos() {
        binding.etNombre.text?.clear()
        binding.etEdad.text?.clear()
        binding.etCorreo.text?.clear()
        binding.etTelefono.text?.clear()
        binding.etDireccion.text?.clear()
        binding.etNombre.requestFocus()
    }
}
