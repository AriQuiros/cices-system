@echo off
echo ========================================
echo EJECUTANDO SCRIPTS CICES
echo ========================================
echo.
echo Conectando a la base de datos CICES...
echo Usuario: cices
echo.

echo ========================================
echo 1. EJECUTANDO insertar_datos_reales_sprint2.sql
echo ========================================
call "%~dp0ejecutar_sql_utf8.bat" "%~dp0insertar_datos_reales_sprint2.sql" "cices/cices123"

if %errorlevel% neq 0 (
    echo ERROR: Fallo al ejecutar insertar_datos_reales_sprint2.sql
    pause
    exit /b 1
)

echo.
echo ========================================
echo 2. EJECUTANDO arreglar_todo.sql (correcciones)
echo ========================================
call "%~dp0ejecutar_sql_utf8.bat" "%~dp0arreglar_todo.sql" "cices/cices123"

if %errorlevel% neq 0 (
    echo ERROR: Fallo al ejecutar arreglar_todo.sql
    pause
    exit /b 1
)

echo.
echo ========================================
echo SCRIPTS EJECUTADOS EXITOSAMENTE
echo ========================================
echo Los proyectos C1766 y C0236 estan listos
echo Usuarios maria.saenz y jaime.fornaguera pueden hacer login con admin123
echo SOLO tienen rol INVESTIGADOR (sin DIRECTOR)
echo.
echo Presiona cualquier tecla para salir...
pause > nul